from setuptools import setup, find_packages

setup(
    name='car_speed_detection',
    version='0.7.1',
    author='Shao-chieh Lien',
    author_email='shaochiehlien@gmail.com',
    packages=find_packages(),
)

