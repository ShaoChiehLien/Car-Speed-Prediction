from setuptools import setup, find_packages

setup(
    name='xworker',
    version='0.7.0',
    author='Shao-chieh Lien',
    author_email='shaochiehlien@gmail.com',
    packages=find_packages(),
)

